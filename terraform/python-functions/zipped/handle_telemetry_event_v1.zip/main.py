"""
GCP HTTP Cloud Function to handle telemetry events.
"""
# -*- coding: utf-8 -*-
import json
import datetime
import logging


def github_event(request):
    """Function to handle incoming event and save event data to BigQuery."""

    # request_timestamp
    request_timestamp = str(datetime.datetime.now())

    # get json from request
    request_json = request.get_json()

    # create response body
    response_body = {
        "request_method": str(request.method),
        "timestamp": request_timestamp,
        "request_json": request_json,
    }

    # build response
    response = {
        "statusCode": 200,
        "body": response_body
    }

    # logging response
    logging.info(response)

    return ('OK', 200)

